"""Transcribe one WAV with Gnani, run support, and synthesize its reply with Gnani."""

import argparse
import json
from pathlib import Path

from src.gnani_voice import synthesize_wav, transcribe_wav
from src.tool_agent import ToolAgent


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("audio", type=Path, help="Mono 16 kHz, 16-bit PCM WAV recording")
    parser.add_argument("--language", default="en-IN", help="Gnani STT code, e.g. en-IN or hi-IN")
    parser.add_argument("--voice-language", default="auto", help="Gnani TTS language, e.g. en-IN, hi-IN, hi-en, or auto")
    parser.add_argument("--voice", default="Nalini", help="Gnani Timbre v2.5 voice name")
    parser.add_argument("--output-dir", type=Path, default=Path("work/results/voice"))
    args = parser.parse_args()

    transcript = transcribe_wav(args.audio, args.language)
    print(f"Transcript: {transcript}")
    agent = ToolAgent()
    reply, tool_calls = agent.respond(transcript)
    audio_path = synthesize_wav(reply, args.output_dir / "assistant_reply.wav", args.voice_language, args.voice)
    sources = [chunk["source_id"] for chunk in agent.kb.retrieve(transcript, top_k=5)]
    record = {
        "audio_input": str(args.audio),
        "transcript": transcript,
        "assistant_reply": reply,
        "tool_calls": tool_calls,
        "retrieved_sources": sources,
        "audio_reply": str(audio_path),
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "turn.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Assistant: {reply}")
    print(f"Audio reply saved to: {audio_path}")
    print(f"Turn record saved to: {args.output_dir / 'turn.json'}")


if __name__ == "__main__":
    main()
