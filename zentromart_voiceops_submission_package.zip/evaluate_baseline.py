"""Run Step 1 against every supplied practice question and save the scores."""

import argparse
import csv
import json
from pathlib import Path
import time

from src.evaluation import score_question
from src.llm_client import answer
from src.prompts import BASELINE_SYSTEM_PROMPT


PROJECT_ROOT = Path(__file__).resolve().parent
DEFAULT_DATASET = PROJECT_ROOT / "work" / "dataset" / "Capstone_Project_Dataset_FTTT_2026"
DEFAULT_OUTPUT = PROJECT_ROOT / "work" / "results" / "baseline_eval.json"


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Evaluate the prompt-only baseline on practice/questions.csv."
    )
    parser.add_argument("--dataset-dir", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument(
        "--delay-seconds", type=float, default=5.0,
        help="Pause between requests to stay within free-tier rate limits.",
    )
    args = parser.parse_args()

    questions_path = args.dataset_dir / "practice" / "questions.csv"
    with questions_path.open(encoding="utf-8-sig", newline="") as handle:
        questions = list(csv.DictReader(handle))

    results = []
    for index, row in enumerate(questions, start=1):
        reply = answer(BASELINE_SYSTEM_PROMPT, row["question"])
        result = score_question(row, reply)
        result["question"] = row["question"]
        result["gold_evidence"] = row["gold_evidence"]
        results.append(result)
        print(f"[{index}/{len(questions)}] {row['id']}: {'PASS' if result['passed'] else 'REVIEW'}")
        if index < len(questions) and args.delay_seconds > 0:
            time.sleep(args.delay_seconds)

    summary = {
        "stage": "step_1_prompt_only_baseline",
        "question_count": len(results),
        "passed_count": sum(item["passed"] for item in results),
        "decision_accuracy": round(
            sum(item["decision_ok"] for item in results) / len(results), 4
        ) if results else 0,
        "fact_and_safety_pass_rate": round(
            sum(item["passed"] for item in results) / len(results), 4
        ) if results else 0,
        "scoring_note": (
            "Literal, case-insensitive checks with punctuation removed; review "
            "native-language equivalents and paraphrases manually."
        ),
        "results": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nSaved results to {args.output}")
    print(
        f"Passed {summary['passed_count']}/{summary['question_count']} | "
        f"decision accuracy {summary['decision_accuracy']:.1%}"
    )


if __name__ == "__main__":
    main()
