"""Run the Step 1 prompt-only baseline for a single text question."""

import argparse
import sys

from src.llm_client import answer
from src.prompts import BASELINE_SYSTEM_PROMPT


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description="Ask the ZentroMart baseline agent.")
    parser.add_argument("question", help="The customer's question")
    args = parser.parse_args()
    print(answer(BASELINE_SYSTEM_PROMPT, args.question))


if __name__ == "__main__":
    main()
