"""Evaluate Step 2 answers, source retrieval, and safety on the practice set."""

import argparse
import csv
import json
import time
from pathlib import Path

from src.evaluation import score_question
from src.knowledge_base import DEFAULT_DATASET
from src.rag_agent import RAGAgent


PROJECT_ROOT = Path(__file__).resolve().parent
DEFAULT_OUTPUT = PROJECT_ROOT / "work" / "results" / "rag_eval_step2.json"


def summarize(results: list[dict], total_questions: int, top_k: int) -> dict:
    scored = [item for item in results if item.get("passed") is not None]
    answerable = [item for item in results if item.get("expected_evidence")]
    matched_chunks = sum(len(item["matched_evidence"]) for item in answerable)
    expected_chunks = sum(len(item["expected_evidence"]) for item in answerable)
    return {
        "stage": "step_2_rag",
        "total_questions": total_questions,
        "completed_questions": len(scored),
        "top_k": top_k,
        "passed_count": sum(item["passed"] for item in scored),
        "decision_accuracy": round(
            sum(item["decision_ok"] for item in scored) / len(scored), 4
        ) if scored else 0,
        "fact_and_safety_pass_rate": round(
            sum(item["passed"] for item in scored) / len(scored), 4
        ) if scored else 0,
        "all_gold_sources_found": sum(
            item["recall"] == 1 for item in answerable
        ),
        "answerable_question_count": len(answerable),
        "all_source_recall_rate": round(
            sum(item["recall"] == 1 for item in answerable) / len(answerable), 4
        ) if answerable else 0,
        "chunk_recall": round(matched_chunks / expected_chunks, 4) if expected_chunks else 0,
        "scoring_note": (
            "Required facts use normalized string checks; manually review multilingual "
            "equivalents and paraphrases before final reporting."
        ),
        "results": results,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate the document-grounded agent.")
    parser.add_argument("--dataset-dir", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--delay-seconds", type=float, default=5.0)
    args = parser.parse_args()

    questions_path = args.dataset_dir / "practice" / "questions.csv"
    with questions_path.open(encoding="utf-8-sig", newline="") as handle:
        questions = list(csv.DictReader(handle))

    results = []
    if args.output.exists():
        try:
            prior = json.loads(args.output.read_text(encoding="utf-8"))
            if prior.get("stage") == "step_2_rag":
                results = prior.get("results", [])
        except (json.JSONDecodeError, OSError):
            results = []
    completed_ids = {item["id"] for item in results}

    agent = RAGAgent(dataset_dir=args.dataset_dir, top_k=args.top_k)
    for index, row in enumerate(questions, start=1):
        if row["id"] in completed_ids:
            continue
        try:
            reply, chunks = agent.respond(row["question"])
        except RuntimeError as exc:
            partial = summarize(results, len(questions), args.top_k)
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(partial, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"Stopped at {row['id']}: {exc}")
            print(f"Progress is saved; rerun this command later to resume. Results: {args.output}")
            raise SystemExit(1)

        result = score_question(row, reply)
        expected = [part.strip() for part in row["gold_evidence"].split(" ; ") if part.strip()]
        returned = [chunk["source_id"] for chunk in chunks]
        matched = [source for source in expected if source in returned]
        result.update(
            {
                "question": row["question"],
                "language": row["language"],
                "expected_evidence": expected,
                "retrieved_evidence": returned,
                "matched_evidence": matched,
                "recall": len(matched) / len(expected) if expected else None,
            }
        )
        results.append(result)
        partial = summarize(results, len(questions), args.top_k)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(partial, ensure_ascii=False, indent=2), encoding="utf-8")
        print(
            f"[{len(results)}/{len(questions)}] {row['id']}: "
            f"{'PASS' if result['passed'] else 'REVIEW'} | "
            f"sources {len(matched)}/{len(expected)}",
            flush=True,
        )
        if index < len(questions) and args.delay_seconds > 0:
            time.sleep(args.delay_seconds)

    final = summarize(results, len(questions), args.top_k)
    args.output.write_text(json.dumps(final, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        f"\nStep 2: {final['passed_count']}/{final['completed_questions']} passed; "
        f"decision accuracy {final['decision_accuracy']:.1%}; "
        f"gold evidence recall {final['chunk_recall']:.1%}."
    )
    print(f"Saved details to {args.output}")


if __name__ == "__main__":
    main()
