"""Step 3: multi-turn agent with guarded synthetic order and ticket tools."""

import importlib.util
import csv
import json
import re
from datetime import date, datetime, timedelta
from pathlib import Path

from src.knowledge_base import DEFAULT_DATASET, KnowledgeBase
from src.llm_client import answer
from src.rag_agent import format_evidence
from src.time_rules import calendar_context


TOOL_AGENT_PROMPT = """You are ZentroMart's customer support AI assistant in a multi-turn conversation.
Answer only from the supplied company evidence and verified tool results. Do not invent
policy, dates, amounts, product details, order details, or completed actions. Treat
20 October 2026 as today's date. Reply entirely in the customer's current language.
For business-day timelines, count Monday through Saturday and skip listed holidays. When
declining a requested action, apologize briefly. Current policy outranks help, FAQs, and marketing.
Follow these tool rules:
- Return exactly one JSON object with keys action, decision, message, order_id, verification_value,
  intent, reason, summary. action is reply, lookup_order, verify_order, or create_ticket.
  decision is answer, clarify, escalate, or refuse.
- For a specific order question, request lookup_order by order ID. Never answer before verification.
- If order ID is missing, ask for it. After an unverified lookup, ask for either registered
  phone last four digits or delivery pincode. Never reveal which value is correct.
- A failed check permits one retry only. After two failed attempts, stop order lookup and
  offer general policy help / support from the registered phone.
- Use verified tool results only for order facts. Never include phone, email, or full address.
- For a required handover, create a ticket first. The summary must contain issue, intent,
  order ID if any, what the customer said, what was checked, and why it is escalated.
- Do not claim a ticket exists unless the tool result says created=true.
- General policy questions need no order lookup or verification.
- When refusing cancellation of an order already shipped, explain the parcel-refusal option
  and give REF-1's refund timeline (usually 7–10 calendar days after the last delivery attempt).
JSON only; put customer-facing words in message. Tool arguments go in their matching keys.
"""


def _load_tools(dataset_dir: Path):
    tool_path = Path(dataset_dir) / "tools" / "tools.py"
    spec = importlib.util.spec_from_file_location("capstone_mock_tools", tool_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load supplied mock tools at {tool_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _extract_json(text: str) -> dict:
    match = re.search(r"\{.*\}", text, re.S)
    if not match:
        raise ValueError("The assistant did not return the required JSON action.")
    result = json.loads(match.group())
    if result.get("action") not in {"reply", "lookup_order", "verify_order", "create_ticket"}:
        raise ValueError("The assistant returned an unsupported action.")
    return result


def _safe_order(order: dict) -> dict:
    """Remove verification proof and direct contact fields before model context."""
    private = {"delivery_pincode", "phone", "phone_last4", "email", "address", "street"}
    return {key: value for key, value in order.items() if key not in private}


class ToolAgent:
    """Conversation state is in memory; verification never persists across sessions."""

    def __init__(self, dataset_dir: Path = DEFAULT_DATASET, top_k: int = 5):
        self.dataset_dir = Path(dataset_dir)
        self.kb = KnowledgeBase(self.dataset_dir)
        self.tools = _load_tools(self.dataset_dir)
        self.top_k = top_k
        self.history: list[dict[str, str]] = []
        self.pending_order_id: str | None = None
        self.verified_order: dict | None = None
        self.verification_failures = 0
        self.ticket_created = False
        self.last_decision = "answer"

    def _context(self, customer_message: str, tool_events: list[dict]) -> str:
        chunks = self.kb.retrieve(customer_message, top_k=self.top_k)
        return_context = self._verified_return_context(customer_message)
        delivery_context = self._verified_delivery_context(customer_message)
        cancellation_context = self._verified_cancellation_context(customer_message)
        return (
            f"Recent conversation: {json.dumps(self.history[-8:], ensure_ascii=False)}\n"
            f"Customer message: {customer_message}\n"
            f"Current conversation state: pending_order_id={self.pending_order_id!r}; "
            f"verified_order={json.dumps(self.verified_order, ensure_ascii=False) if self.verified_order else 'null'}; "
            f"verification_failures={self.verification_failures}; ticket_created={self.ticket_created}.\n"
            f"Company evidence:\n{format_evidence(chunks)}\n"
            f"Tool results from this turn: {json.dumps(tool_events, ensure_ascii=False)}"
            f"{return_context}{delivery_context}{cancellation_context}"
        )

    def _verified_cancellation_context(self, customer_message: str) -> str:
        if not self.verified_order or not re.search(r"cancel|stop it|रद्द|कैंसिल", customer_message, re.I):
            return ""
        status = str(self.verified_order.get("status", "")).casefold()
        if status not in {"shipped", "out_for_delivery", "delivery_attempted"}:
            return ""
        sources = {chunk["source_id"]: chunk for chunk in self.kb.chunks}
        can = sources.get("CAN-2")
        refund = sources.get("REF-1")
        text = "\n".join(item["text"].strip() for item in (can, refund) if item)
        if not text:
            return ""
        return (
            "\n\nPOLICY CHECK (CAN-2 and REF-1): " + text
            + "\nRequired response: state that cancellation is unavailable after shipment; "
            "the customer may refuse delivery; after return to the warehouse, refund usually "
            "takes 7–10 calendar days after the last delivery attempt."
        )

    def _verified_delivery_context(self, customer_message: str) -> str:
        text = customer_message.casefold()
        if not any(term in text for term in ("not at home", "away", "घर पर", "घर पे", "नहीं रह", "डिलीवरी का प्रयास")):
            return ""
        delivery = next((chunk for chunk in self.kb.chunks if chunk["source_id"] == "DEL-3"), None)
        if not delivery:
            return ""
        return (
            "\n\nPOLICY CHECK (DEL-3): " + delivery["text"].strip()
            + " Use only these delivery-attempt steps; do not invent a next delivery date."
        )

    def _verified_return_context(self, customer_message: str) -> str:
        if not self.verified_order or not re.search(r"return|back|send it|वापस|लौटा", customer_message, re.I):
            return ""
        order = self.verified_order
        sku = order.get("return_sku")
        if not sku:
            items = order.get("items") or []
            sku = items[0].get("sku") if items else None
        if not sku or not order.get("delivered_on"):
            return ""
        with (self.dataset_dir / "data" / "products.csv").open(encoding="utf-8-sig", newline="") as handle:
            product = next((row for row in csv.DictReader(handle) if row["sku"] == sku), None)
        if not product:
            return ""
        policy = (self.dataset_dir / "kb" / "pol_returns_v4.md").read_text(encoding="utf-8")
        section_match = re.search(r"## \[RET-2\].*?(?=\n## |\Z)", policy, re.S)
        section = section_match.group() if section_match else ""
        windows = {
            match.group(2).strip(): int(match.group(1))
            for match in re.finditer(r"\|[^|]+\|\s*(\d+) days\s*\|\s*`([^`]+)`", section)
        }
        category = product.get("return_category", "")
        if category not in windows:
            if category == "grocery":
                return "\n\nPOLICY CHECK: The verified order item is in the grocery category; RET-2 says it is not returnable."
            return ""
        days = windows[category]
        placed = date.fromisoformat(order["placed_at"][:10])
        delivered = date.fromisoformat(order["delivered_on"][:10])
        festive = re.search(r"(\d+) days of delivery", policy)
        if category == "fashion" and festive:
            match = re.search(r"between (\d{2}) October and (\d{2}) October 2026", policy)
            if match and date(2026, 10, int(match.group(1))) <= placed <= date(2026, 10, int(match.group(2))):
                days = int(festive.group(1))
        deadline = delivered + timedelta(days=days)
        return (
            "\n\nDETERMINISTIC RETURN-WINDOW CHECK (verified order + products.csv + RET-2/RET-8): "
            f"item category={category}; delivered={delivered:%d %B %Y}; window={days} calendar days; "
            f"last eligible date={deadline:%d %B %Y}. State this date if asked."
        )

    def _ticket_is_eligible(self, customer_message: str) -> bool:
        customer_text = " ".join(
            item["text"] for item in self.history if item["role"] == "customer"
        ) + " " + customer_message
        text = customer_text.casefold()
        explicit_human = any(term in text for term in (
            "human", "agent", "person", "manager", "इंसान", "मानव", "एजेंट", "सहकर्मी",
        ))
        explicit_escalation = any(term in text for term in (
            "police", "consumer court", "legal action", "lawsuit", "fraud", "unauthorized",
            "not my order", "didn't make", "did not make", "burning smell", "sparks",
            "swelling battery", "injury", "injured",
        ))
        repeat_contact = (
            self.verified_order is not None
            and self.verified_order.get("contacts_last_7_days", 0) >= 2
            and any(term in text for term in ("third", "teesri", "तीसरी", "same issue", "isi baare"))
        )
        high_value_damage = (
            any(term in text for term in ("damaged", "damage", "broken", "cracked", "defective", "wrong item"))
            and any(term in text for term in ("over 10,000", "above 10,000", "more than 10000", "₹10,000", "rs 10,000", "10,000"))
        )
        if not high_value_damage and self.verified_order and any(
            term in text for term in ("damaged", "damage", "broken", "cracked", "defective", "wrong item")
        ):
            damage_sku = self.verified_order.get("damage_sku")
            if damage_sku:
                with (self.dataset_dir / "data" / "products.csv").open(encoding="utf-8-sig", newline="") as handle:
                    product = next((row for row in csv.DictReader(handle) if row["sku"] == damage_sku), None)
                high_value_damage = bool(product and int(product["price_inr"]) > 10000)
        overdue_refund = "refund" in text and self._refund_overdue()
        order_id_in_text = bool(re.search(r"(?<!\d)\d[\d\s-]{6,14}\d(?!\d)", customer_text))
        if order_id_in_text and not self.verified_order:
            return explicit_human
        return explicit_human or explicit_escalation or high_value_damage or overdue_refund or repeat_contact

    def _policy_requires_refusal(self, customer_message: str) -> bool:
        if not self.verified_order:
            return False
        text = customer_message.casefold()
        order = self.verified_order
        shipped = str(order.get("status", "")).casefold() in {"shipped", "out_for_delivery", "delivery_attempted"}
        if shipped and re.search(r"cancel|stop it|रद्द|कैंसिल", text):
            return True
        asks_compensation = any(term in text for term in ("compensation", "voucher", "मुआवज़ा", "मुआवजा", "वाउचर", "muaawza"))
        standard = str(order.get("delivery_type", "")).casefold() == "standard"
        return asks_compensation and standard

    def _refund_overdue(self) -> bool:
        """Apply ESC-1's more-than-three-business-days-past-maximum rule."""
        if not self.verified_order:
            return False
        order = self.verified_order
        initiated = None
        method = None
        for prefix in ("return", "cancellation", "rto"):
            if order.get(f"{prefix}_refund_initiated_on"):
                initiated = order[f"{prefix}_refund_initiated_on"]
                method = order.get(f"{prefix}_refund_method", "")
                if prefix == "return" and order.get("return_refund_completed_on"):
                    return False
                break
        if not initiated or not method:
            return False
        question = f"Refund to {method} initiated on {initiated}. What is its maximum arrival date?"
        evidence = [chunk for chunk in self.kb.chunks if chunk["source_id"] == "REF-2"]
        context = calendar_context(question, evidence, self.dataset_dir)
        match = re.search(r"to\s+(\d{2} \w+ 2026)", context)
        if not match:
            return False
        due = datetime.strptime(match.group(1), "%d %B %Y").date()
        today = date(2026, 10, 20)
        with (self.dataset_dir / "data" / "holidays.csv").open(encoding="utf-8-sig", newline="") as handle:
            holidays = {date.fromisoformat(row["date"]) for row in csv.DictReader(handle)}
        past_due_business_days = 0
        cursor = due
        while cursor < today:
            cursor += timedelta(days=1)
            if cursor.weekday() != 6 and cursor not in holidays:
                past_due_business_days += 1
        return past_due_business_days > 3

    def respond(self, customer_message: str) -> tuple[str, list[str]]:
        """Process one customer turn, enforcing lookup, verification and ticket gates."""
        tool_events: list[dict] = []
        called: list[str] = []
        final_decision = "answer"
        order_match = re.search(r"(?<!\d)(\d[\d\s-]{6,14}\d)(?!\d)", customer_message)
        mentioned_order_id = "".join(c for c in order_match.group(1) if c.isascii() and c.isdigit()) if order_match else ""
        proof_match = re.search(r"(?<!\d)(\d{4}|\d{6})(?!\d)", customer_message) if self.pending_order_id else None
        model_message = customer_message
        if proof_match:
            model_message = customer_message[:proof_match.start()] + "[verification value redacted]" + customer_message[proof_match.end():]
        # A model can request a tool, but the executor is the security boundary.
        for _ in range(3):
            action = _extract_json(answer(TOOL_AGENT_PROMPT, self._context(model_message, tool_events)))
            # Enforce obvious order-ID / pending-proof transitions even if the model
            # chooses a plain reply. This makes verification a code-level gate.
            if mentioned_order_id and (not self.verified_order or mentioned_order_id != self.verified_order.get("order_id")):
                if self.verified_order and mentioned_order_id != self.verified_order.get("order_id"):
                    self.verified_order = None
                    self.verification_failures = 0
                action.update(action="lookup_order", order_id=mentioned_order_id)
                final_decision = "clarify"
            elif proof_match and self.pending_order_id:
                action.update(action="verify_order", verification_value=proof_match.group(1))
            if self._ticket_is_eligible(customer_message) and not self.ticket_created:
                customer_details = " ".join(item["text"] for item in self.history if item["role"] == "customer")
                customer_details = re.sub(r"(?<!\d)(?:\d{4}|\d{6})(?!\d)", "[verification redacted]", customer_details + " " + customer_message)
                order_id = self.verified_order.get("order_id") if self.verified_order else None
                if self._refund_overdue() and "refund" in customer_details.casefold():
                    reason = "overdue_refund"
                elif self.verified_order and self.verified_order.get("damage_sku") and any(term in customer_details.casefold() for term in ("damaged", "damage", "broken", "cracked")):
                    reason = "high_value_damage"
                else:
                    reason = "customer_requested_human_or_policy_escalation"
                action.update(
                    action="create_ticket",
                    order_id=order_id,
                    intent=reason,
                    reason=reason,
                    summary=(
                        f"Issue: {customer_details}. Intent: {reason}. "
                        f"Order ID: {order_id or 'not provided'}. "
                        f"Customer statements recorded above. Checked: "
                        f"{'order lookup completed after identity verification' if order_id else 'customer has not provided an order ID'}. "
                        f"Escalation reason: {reason}."
                    ),
                )
                final_decision = "escalate"
            name = action["action"]
            if name == "reply":
                decision = action.get("decision", "answer")
                if self._policy_requires_refusal(customer_message):
                    decision = "refuse"
                just_verified = bool("lookup_order" in called and self.verified_order)
                if decision in {"answer", "clarify", "escalate", "refuse"} and not just_verified:
                    final_decision = decision
                reply = action.get("message", "I’m sorry, I couldn’t complete that request. Please try again.")
                if final_decision == "refuse" and not any(term in reply.casefold() for term in ("sorry", "apolog", "maaf", "माफ़", "माफी")):
                    if re.search(r"[\u0900-\u097f]", customer_message):
                        reply = "माफ़ कीजिए, " + reply
                    elif any(term in customer_message.casefold() for term in ("hai", "mujhe", "karna", "nahi")):
                        reply = "Maaf kijiye, " + reply
                    else:
                        reply = "I’m sorry, " + reply
                break
            if name == "lookup_order":
                if self.verified_order:
                    tool_events.append({"error": "This conversation already has a verified order."})
                    continue
                digits = "".join(c for c in str(action.get("order_id") or customer_message) if c.isascii() and c.isdigit())
                if not digits:
                    reply = action.get("message") or "Please share the order ID so I can look it up."
                    break
                self.pending_order_id = digits
                result = self.tools.lookup_order(digits)
                called.append("lookup_order")
                final_decision = "clarify"
                tool_events.append({"tool": "lookup_order", "result": result})
                reply = "To protect your order details, please share either the last four digits of the registered phone number or the delivery pincode."
                break
            if name == "verify_order":
                proof = str(action.get("verification_value") or "").strip()
                if not self.pending_order_id or self.verification_failures >= 2:
                    tool_events.append({"error": "No eligible pending verification."})
                    continue
                result = self.tools.lookup_order(self.pending_order_id, proof)
                called.append("lookup_order")
                if result.get("verified"):
                    self.verified_order = result
                    self.pending_order_id = None
                    tool_events.append({"tool": "lookup_order", "result": {"verified": True, "order": _safe_order(result)}})
                else:
                    self.verification_failures += 1
                    tool_events.append({"tool": "lookup_order", "result": {"verified": False}})
                    if self.verification_failures >= 2:
                        final_decision = "refuse"
                        reply = "I couldn’t verify the order, so I can’t share its details. Please contact support from the registered phone, or I can still help with general policy questions."
                        break
                    reply = "That didn’t match. Please try once more with the last four digits of the registered phone number or the delivery pincode."
                    final_decision = "clarify"
                    break
                # Ask the model to respond to the verified facts, without the proof value.
                final_decision = "answer"
                continue
            if name == "create_ticket":
                if self.ticket_created:
                    tool_events.append({"error": "A ticket was already created in this conversation."})
                    continue
                if not self._ticket_is_eligible(customer_message):
                    final_decision = "clarify"
                    reply = (
                        "Thanks, I’ve verified the order. What issue would you like me to help with?"
                        if self.verified_order
                        else "I can help with the issue first. Please share the order ID if it concerns a specific order."
                    )
                    break
                order_id = self.verified_order.get("order_id") if self.verified_order else None
                summary = str(action.get("summary") or "").strip()
                summary = re.sub(r"(?<!\d)\d{4}(?!\d)", "[verification redacted]", summary)
                if order_id and order_id not in summary:
                    summary = f"Order {order_id}. {summary}"
                result = self.tools.create_ticket(
                    summary=summary,
                    order_id=order_id,
                    reason=str(action.get("reason") or "human_handover"),
                    intent=str(action.get("intent") or "support_request"),
                )
                called.append("create_ticket")
                tool_events.append({"tool": "create_ticket", "result": result})
                if result.get("created"):
                    self.ticket_created = True
                    final_decision = "escalate"
                    reply = f"I’ve created a support ticket ({result['ticket_id']}) for a human colleague to review."
                else:
                    final_decision = "escalate"
                    reply = "I couldn’t create the handover ticket just now. I’m unable to confirm it was submitted; please contact support directly."
                break
        else:
            reply = "I’m sorry, I couldn’t complete that request safely. A human colleague can help."
            final_decision = "escalate"

        if not self.history and re.search(r"[\u0900-\u097f]", customer_message):
            reply = re.sub(r"^(?:Hello|Hi)[^.!?]*assistant[.!?]\s*", "", reply, flags=re.I)
            reply = re.sub(r"^(?:नमस्ते[!,.]?\s*)+", "", reply)
            reply = "नमस्ते, मैं ZentroMart का AI सहायक हूँ। " + reply
        elif not self.history and not any(term in reply.casefold() for term in ("ai assistant", "ai support")):
            reply = "Hello, I’m ZentroMart’s AI support assistant. " + reply
        stored_message = re.sub(r"(?<!\d)(?:\d{4}|\d{6})(?!\d)", "[verification redacted]", customer_message)
        self.history.extend([
            {"role": "customer", "text": stored_message},
            {"role": "assistant", "text": reply},
        ])
        self.last_decision = final_decision
        return reply, called
