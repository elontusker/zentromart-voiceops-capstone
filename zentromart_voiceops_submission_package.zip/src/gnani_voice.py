"""Gnani speech adapters using the official gnani-vachana Python SDK."""

import os
import struct
import wave
from pathlib import Path

from src.llm_client import _load_local_env


def _api_key() -> str:
    _load_local_env()
    key = os.getenv("GNANI_API_KEY", "").strip()
    if not key or key == "replace_me":
        raise RuntimeError("Add your Gnani key to GNANI_API_KEY in .env before using voice features.")
    return key


def transcribe_wav(path: Path, language_code: str = "en-IN") -> str:
    """Transcribe a mono 16 kHz WAV with Gnani's official STT client."""
    try:
        from gnani.stt import GnaniSTTClient
    except ImportError as exc:
        raise RuntimeError("Install project packages with: python -m pip install -r requirements.txt") from exc

    path = Path(path)
    with wave.open(str(path), "rb") as audio:
        if audio.getnchannels() != 1 or audio.getsampwidth() != 2 or audio.getframerate() != 16000:
            raise ValueError("Voice input must be a mono, 16 kHz, 16-bit PCM WAV file.")

    client = GnaniSTTClient(api_key=_api_key())
    result = client.transcribe(str(path), language_code=language_code)
    transcript = str(result.get("transcript", "")).strip()
    if not transcript:
        raise RuntimeError("Gnani STT returned no transcript. Check the audio and language code.")
    return transcript


def synthesize_wav(text: str, output_path: Path, language: str = "auto", voice: str = "Nalini") -> Path:
    """Create a WAV reply with Gnani's official Timbre v2.5 TTS client."""
    try:
        from gnani.tts import AudioConfig, GnaniTTSClient
    except ImportError as exc:
        raise RuntimeError("Install project packages with: python -m pip install -r requirements.txt") from exc

    client = GnaniTTSClient(api_key=_api_key())
    audio_bytes = client.synthesize(
        text,
        voice=voice,
        model="timbre-v2.5",
        language=language,
        speed=1.0,
        audio_config=AudioConfig(
            sample_rate=24000,
            encoding="linear_pcm",
            num_channels=1,
            sample_width=2,
            container="wav",
        ),
    )
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    audio = bytearray(audio_bytes)
    # Some streaming responses use 0xFFFFFFFF as a WAV length placeholder.
    # Normalize that sentinel so common audio players see the actual duration.
    if (
        len(audio) >= 44
        and audio[:4] == b"RIFF"
        and audio[8:12] == b"WAVE"
        and audio[12:16] == b"fmt "
        and audio[36:40] == b"data"
    ):
        if struct.unpack_from("<I", audio, 4)[0] == 0xFFFFFFFF:
            struct.pack_into("<I", audio, 4, len(audio) - 8)
        if struct.unpack_from("<I", audio, 40)[0] == 0xFFFFFFFF:
            struct.pack_into("<I", audio, 40, len(audio) - 44)
    output_path.write_bytes(audio)

    with wave.open(str(output_path), "rb") as check:
        if check.getnchannels() != 1 or check.getsampwidth() != 2 or check.getframerate() != 24000:
            raise RuntimeError("Gnani TTS returned an unexpected WAV format.")
    return output_path
