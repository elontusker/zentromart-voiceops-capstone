"""Load ZentroMart evidence and retrieve relevant policy/data chunks."""

import csv
import hashlib
import json
import math
import os
import re
import urllib.error
import urllib.request
import unicodedata
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATASET = PROJECT_ROOT / "work" / "dataset" / "Capstone_Project_Dataset_FTTT_2026"
SECTION_PATTERN = re.compile(r"^##\s+\[([^\]]+)\]\s+(.+?)\s*$", re.MULTILINE)
STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "been", "can", "could",
    "did", "do", "does", "for", "from", "get", "has", "have", "how", "i",
    "in", "is", "it", "its", "me", "my", "of", "on", "or", "please",
    "the", "this", "to", "was", "we", "what", "when", "where", "which",
    "will", "with", "would", "you", "your", "hai", "hain", "ka", "ki",
    "ko", "kya", "mein", "mujhe", "mera", "meri", "pe", "par", "का", "की",
    "के", "को", "क्या", "है", "हैं", "मैं", "मुझे", "मेरी", "मेरा", "में",
}

# Search-only vocabulary expansion. These are synonyms, not stored answers.
SYNONYMS = {
    "back": {"return", "refund", "pickup"},
    "send": {"return", "pickup"},
    "sent": {"return", "pickup"},
    "collect": {"pickup", "reverse", "collection"},
    "collection": {"pickup", "reverse", "collect"},
    "courier": {"delivery", "shipment", "pickup"},
    "parcel": {"order", "delivery", "shipment"},
    "money": {"refund", "payment", "amount"},
    "cash": {"refund", "payment"},
    "paise": {"refund", "payment", "amount"},
    "wapas": {"return", "refund"},
    "वापस": {"return", "refund"},
    "रिफंड": {"refund", "payment"},
    "खोल": {"opened", "open", "seal"},
    "खोला": {"opened", "open", "seal"},
    "खोलने": {"opened", "open", "seal"},
    "खराब": {"damaged", "defective", "wrong"},
    "डिलीवरी": {"delivery", "shipped", "delivered"},
    "रद्द": {"cancel", "cancellation"},
    "रद्दीकरण": {"cancel", "cancellation"},
    "कितने": {"how", "days", "window", "long"},
    "दिन": {"days", "business", "calendar"},
    "कब": {"when", "timeline", "days"},
    "नहीं": {"not", "cannot", "unavailable"},
    "aaya": {"arrived", "delivered", "delivery"},
    "aya": {"arrived", "delivered", "delivery"},
    "nahi": {"not", "cannot"},
    "wapas": {"return", "refund"},
    "kitne": {"how", "days", "window"},
    "din": {"days", "business", "calendar"},
    "kharab": {"damaged", "defective", "wrong"},
    "paise": {"refund", "payment", "amount"},
    "kab": {"when", "timeline", "days"},
    "unopened": {"open", "opened", "seal"},
    "opened": {"open", "unopened", "seal"},
    "लौटाने": {"return", "returns", "window"},
    "लौटाना": {"return", "returns", "window"},
    "लौटाऊँ": {"return", "returns", "window"},
    "लौटाना": {"return", "returns", "window"},
    "लौट": {"return", "returns", "window"},
    "मिलेंगे": {"days", "window", "return"},
    "मिलती": {"days", "window", "return"},
    "मिलता": {"days", "window", "return"},
    "दिनों": {"days", "calendar", "business"},
    "खोल": {"open", "opened", "unopened", "seal"},
    "लिपस्टिक": {"lipstick", "beauty", "opened"},
    "नोटबुक": {"notebook", "books", "stationery"},
    "लैपटॉप": {"laptop", "high", "value", "damage"},
    "शिप": {"shipped", "shipment", "delivery"},
    "हो": {"status", "shipped", "delivered"},
    "गया": {"status", "shipped", "delivered"},
    "ऑर्डर": {"order", "shipment"},
    "कैंसिल": {"cancel", "cancellation"},
    "करूँ": {"help", "damaged", "support"},
    "सामान": {"item", "product", "goods"},
    "टूटा": {"broken", "damaged", "crack"},
    "टूटी": {"broken", "damaged", "crack"},
    "आया": {"arrived", "delivery", "delivered"},
    "आया": {"arrived", "delivery", "delivered"},
    "person": {"another", "someone", "neighbor", "privacy", "account"},
    "building": {"neighbor", "another", "privacy"},
    "crack": {"cracked", "damage", "damaged", "physical", "high", "value", "escalate"},
    "cracked": {"crack", "damage", "damaged", "physical", "high", "value", "escalate"},
    "laptop": {"high", "value", "electronics"},
    "stop": {"cancel", "cancellation"},
    "stopit": {"cancel", "cancellation"},
    "torn": {"tear", "damaged", "wrong"},
    "shoes": {"shoe", "fashion", "clothing"},
    "kurta": {"fashion", "clothing"},
    "bag": {"fashion", "clothing"},
    "swimsuit": {"innerwear", "fashion"},
    "briefs": {"innerwear", "fashion"},
    "suitcase": {"fashion", "luggage"},
    "कैंसिल": {"cancel", "cancellation"},
    "रिफंड": {"refund", "payment"},
    "रुपये": {"money", "refund", "amount"},
}


def _word_tokens(text: str) -> list[str]:
    """Split on punctuation while keeping Devanagari vowel marks attached."""
    words = []
    current = []
    for char in unicodedata.normalize("NFC", text or ""):
        category = unicodedata.category(char)
        if category[0] in {"L", "N"} or (category[0] == "M" and current):
            current.append(char)
        elif current:
            words.append("".join(current).casefold())
            current = []
    if current:
        words.append("".join(current).casefold())
    return words


def _tokens(text: str) -> list[str]:
    words = _word_tokens(text)
    normalized = []
    for word in words:
        if word in STOPWORDS:
            continue
        normalized.append(word)
        # A light English normalization handles common plural and tense forms.
        if len(word) > 5 and word.endswith("ies"):
            normalized.append(word[:-3] + "y")
        elif len(word) > 4 and word.endswith("ing"):
            normalized.append(word[:-3])
        elif len(word) > 4 and word.endswith("ed"):
            normalized.append(word[:-2])
        elif len(word) > 3 and word.endswith("s"):
            normalized.append(word[:-1])
        normalized.extend(SYNONYMS.get(word, ()))
    return normalized


def _front_matter(text: str) -> tuple[dict[str, str], str]:
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, text
    end = next((i for i in range(1, len(lines)) if lines[i].strip() == "---"), None)
    if end is None:
        return {}, text
    metadata = {}
    for line in lines[1:end]:
        if ":" in line:
            key, value = line.split(":", 1)
            metadata[key.strip()] = value.strip().strip("\"'")
    return metadata, "\n".join(lines[end + 1 :])


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


class KnowledgeBase:
    """Hybrid semantic-vector and BM25 index over approved evidence chunks."""

    def __init__(self, dataset_dir: Path = DEFAULT_DATASET):
        self.dataset_dir = Path(dataset_dir)
        self.chunks: list[dict] = []
        self._load_markdown()
        self._load_catalog()
        self._by_source = {chunk["source_id"]: chunk for chunk in self.chunks}
        self._query_vectors: dict[str, list[float]] = {}
        self._build_index()
        self._build_vector_index()

    @staticmethod
    def _embed(texts: list[str]) -> list[list[float]]:
        """Create local embeddings using Ollama's OpenAI-free embedding endpoint."""
        model = os.getenv("EMBEDDING_MODEL", "nomic-embed-text")
        base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/")
        vectors = []
        for start in range(0, len(texts), 8):
            # Keep each passage within the small local model's context window.
            batch = [text[:6000] for text in texts[start:start + 8]]
            payload = json.dumps({"model": model, "input": batch}).encode()
            request = urllib.request.Request(
                f"{base_url}/api/embed", data=payload,
                headers={"Content-Type": "application/json"}, method="POST",
            )
            try:
                with urllib.request.urlopen(request, timeout=180) as response:
                    result = json.loads(response.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                details = exc.read().decode("utf-8", errors="replace")
                raise RuntimeError(f"Ollama embedding request failed: {details}") from exc
            except (urllib.error.URLError, TimeoutError) as exc:
                raise RuntimeError(
                    f"Could not reach Ollama at {base_url}. Open Ollama and make sure "
                    f"'{model}' is installed (ollama pull {model})."
                ) from exc
            vectors.extend(result["embeddings"])
        return vectors

    def _build_vector_index(self) -> None:
        texts = [f"{chunk['title']}\n{chunk['text']}" for chunk in self.chunks]
        model = os.getenv("EMBEDDING_MODEL", "nomic-embed-text")
        fingerprint = hashlib.sha256(
            (model + "\0" + "\0".join(texts)).encode("utf-8")
        ).hexdigest()
        cache_path = PROJECT_ROOT / "work" / "results" / "vector_index_cache.json"
        if cache_path.exists():
            try:
                cached = json.loads(cache_path.read_text(encoding="utf-8"))
                if cached.get("fingerprint") == fingerprint:
                    self._vectors = cached["vectors"]
                    return
            except (OSError, ValueError, KeyError):
                pass

        self._vectors = []
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        for start in range(0, len(texts), 8):
            self._vectors.extend(self._embed(texts[start:start + 8]))
            cache_path.write_text(
                json.dumps({"fingerprint": fingerprint, "vectors": self._vectors}),
                encoding="utf-8",
            )

    def _load_markdown(self) -> None:
        for path in sorted((self.dataset_dir / "kb").glob("*.md")):
            text = path.read_text(encoding="utf-8")
            metadata, body = _front_matter(text)
            headings = list(SECTION_PATTERN.finditer(body))
            for index, heading in enumerate(headings):
                start = heading.end()
                end = headings[index + 1].start() if index + 1 < len(headings) else len(body)
                content = body[start:end].strip()
                if not content:
                    continue
                self.chunks.append(
                    {
                        "source_id": heading.group(1),
                        "title": heading.group(2).strip(),
                        "text": content,
                        "doc_id": metadata.get("doc_id", path.stem),
                        "doc_type": metadata.get("doc_type", "unknown"),
                        "status": metadata.get("status", "current"),
                        "effective_from": metadata.get("effective_from", ""),
                        "language": metadata.get("language", "en"),
                        "file": path.name,
                    }
                )

    def _load_catalog(self) -> None:
        products = _read_csv(self.dataset_dir / "data" / "products.csv")
        for row in products:
            self.chunks.append(
                {
                    "source_id": f"products.csv:{row['sku']}",
                    "title": row["title"],
                    "text": "; ".join(f"{key}: {value}" for key, value in row.items() if value),
                    "doc_id": "PRODUCT-CATALOG",
                    "doc_type": "data",
                    "status": "current",
                    "effective_from": "",
                    "language": "en",
                    "file": "products.csv",
                }
            )

        pincodes = _read_csv(self.dataset_dir / "data" / "pincodes.csv")
        for row in pincodes:
            self.chunks.append(
                {
                    "source_id": f"pincodes.csv:{row['pincode']}",
                    "title": f"Delivery service for pincode {row['pincode']}",
                    "text": "; ".join(f"{key}: {value}" for key, value in row.items() if value),
                    "doc_id": "PINCODE-TABLE",
                    "doc_type": "data",
                    "status": "current",
                    "effective_from": "",
                    "language": "en",
                    "file": "pincodes.csv",
                }
            )

    def _build_index(self) -> None:
        self._document_tokens = [_tokens(c["title"] + " " + c["text"]) for c in self.chunks]
        self._document_lengths = [len(t) for t in self._document_tokens]
        self._average_length = sum(self._document_lengths) / max(len(self.chunks), 1)
        self._document_frequency: dict[str, int] = {}
        for tokens in self._document_tokens:
            for token in set(tokens):
                self._document_frequency[token] = self._document_frequency.get(token, 0) + 1

    def _priority(self, chunk: dict) -> float:
        score = 0.0
        kind = chunk["doc_type"]
        if kind == "policy":
            score += 1.1
        elif kind == "agent_guide":
            score += 0.6
        elif kind == "help":
            score += 0.25
        elif kind == "marketing":
            score -= 0.25
        elif kind == "data":
            score -= 0.1
        if chunk["status"] == "superseded":
            score -= 0.5
        return score

    def retrieve(
        self, query: str, top_k: int = 5, query_vector: list[float] | None = None
    ) -> list[dict]:
        query_tokens = _tokens(query)
        if not query_tokens or not self.chunks:
            return []

        n_docs = len(self.chunks)
        if query_vector is None:
            query_vector = self._query_vectors.get(query)
        if query_vector is None:
            query_vector = self._embed([query])[0]
        k1, b = 1.5, 0.75
        scored = []
        score_by_index = {}
        exact_skus = set(re.findall(r"\b[A-Z]{3}-\d{4}\b", query.upper()))
        vector_scores = [
            sum(a * b for a, b in zip(query_vector, vector))
            for vector in self._vectors
        ]
        for index, chunk in enumerate(self.chunks):
            tokens = self._document_tokens[index]
            frequencies: dict[str, int] = {}
            for token in tokens:
                frequencies[token] = frequencies.get(token, 0) + 1
            length = self._document_lengths[index]
            score = self._priority(chunk)
            for token in query_tokens:
                tf = frequencies.get(token, 0)
                if not tf:
                    continue
                df = self._document_frequency.get(token, 0)
                idf = math.log(1 + (n_docs - df + 0.5) / (df + 0.5))
                denom = tf + k1 * (1 - b + b * length / max(self._average_length, 1))
                score += idf * tf * (k1 + 1) / denom
            title_tokens = set(_tokens(chunk["title"]))
            score += 0.25 * sum(
                math.log(1 + (n_docs - self._document_frequency.get(token, 0) + 0.5)
                         / (self._document_frequency.get(token, 0) + 0.5))
                for token in set(query_tokens) & title_tokens
            )
            if chunk["source_id"] in {f"products.csv:{sku}" for sku in exact_skus}:
                score += 8.0
            # Reciprocal rank fusion combines semantic similarity with the
            # existing exact-token ranker without letting either dominate.
            score_by_index[index] = score
            if score > self._priority(chunk):
                scored.append((score, index))

        lexical_ranks = {index: rank for rank, (_, index) in enumerate(
            sorted(scored, key=lambda item: item[0], reverse=True), start=1
        )}
        vector_order = sorted(range(n_docs), key=lambda i: vector_scores[i], reverse=True)
        vector_ranks = {index: rank for rank, index in enumerate(vector_order, start=1)}
        fused = {}
        for index, chunk in enumerate(self.chunks):
            # Preserve exact SKU lookups and use priority only as a small tie-break.
            reciprocal = 1 / (60 + lexical_ranks.get(index, 10_000))
            reciprocal += 1 / (60 + vector_ranks[index])
            if chunk["source_id"] in {f"products.csv:{sku}" for sku in exact_skus}:
                reciprocal += 1.0
            fused[index] = reciprocal + max(self._priority(chunk), 0) * 1e-6
        scored = [(score, index) for index, score in fused.items()]

        scored.sort(key=lambda item: item[0], reverse=True)
        selected = [
            {**self.chunks[index], "score": round(score, 4)}
            for score, index in scored[:top_k]
        ]
        selected_ids = {item["source_id"] for item in selected}

        # Intent routes retrieve the policy sections a lexical ranker can miss
        # when a customer uses different words or writes in Hindi/Hinglish.
        raw = set(_word_tokens(query))
        words = set(query_tokens)
        return_intent = bool(
            raw & {"return", "returns", "back", "wapas", "वापस", "लौटाने", "लौटाना", "लौटाऊँ"}
        )
        refund_intent = bool(raw & {"refund", "refunds", "refunded", "रिफंड", "paise", "money", "cashback"})
        cancel_intent = bool(raw & {"cancel", "cancellation", "stop", "stopit", "कैंसिल", "रद्द"})
        warranty_intent = bool(raw & {"warranty", "assured", "guarantee", "वारंटी"})
        damage_intent = bool(raw & {
            "damage", "damaged", "broken", "crack", "cracked", "torn", "wrong", "missing",
            "खराब", "टूटा", "टूटी", "सामान",
        })
        order_abuse_intent = (
            ("order" in words or "ऑर्डर" in raw)
            and bool(raw & {"never", "someone", "another", "person", "building", "unauthorized"})
        )
        explicit_date = bool(
            re.search(r"\b\d{1,2}\s+(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\b", query, re.I)
            or re.search(r"\b20\d{2}-\d{2}-\d{2}\b", query)
        )
        relative_date = bool(raw & {"today", "yesterday", "tomorrow", "parso", "kal", "परसों", "कल"})

        required_ids = []
        if return_intent:
            required_ids.append("RET-2")
            if raw & {"open", "opened", "unopened", "खोल", "खोला", "खोलने"}:
                required_ids.append("RET-4")
            if raw & {"festive", "sale"}:
                required_ids.append("RET-8")
            product_chunks = [item for item in selected if item["source_id"].startswith("products.csv:")]
            product_text = " ".join(item["text"].casefold() for item in product_chunks)
            if "fashion" in product_text or raw & {"shoes", "shoe", "kurta", "bag", "clothing"}:
                required_ids.append("RET-8")
            if "electronics" in product_text or raw & {"electronics", "smartwatch", "laptop", "smartphone"}:
                required_ids.extend(["RET-3"])
            if "innerwear" in product_text or raw & {"innerwear", "swimsuit", "briefs", "lingerie"}:
                required_ids.append("RET-5")
            if explicit_date and raw & {"july", "jun", "june", "before"}:
                required_ids.append("RETv3-2")
        if refund_intent:
            required_ids.extend(["REF-2", "KB-00.1"])
            if explicit_date or raw & {"date", "when", "days", "business"}:
                required_ids.append("KB-00.3")
            if raw & {"cod", "cash", "returned", "return"}:
                required_ids.append("REF-3")
        if relative_date:
            required_ids.append("KB-00.2")
        if cancel_intent:
            required_ids.append("CAN-2")
        if warranty_intent:
            required_ids.extend(["WAR-1", "WAR-2"])
        if damage_intent:
            required_ids.extend(["DWM-1", "DWM-2"])
            if raw & {"crack", "cracked", "laptop", "high", "value"}:
                required_ids.extend(["DWM-3", "ESC-1"])
        if order_abuse_intent:
            required_ids.append("ESC-1")
        if raw & {"phone", "number", "building", "neighbor", "person"}:
            required_ids.extend(["ESC-4", "IDV-4"])
        for source_id in dict.fromkeys(required_ids):
            chunk = self._by_source.get(source_id)
            if chunk and source_id not in selected_ids:
                index = self.chunks.index(chunk)
                selected.append({**chunk, "score": round(score_by_index.get(index, 0.0), 4), "routed": True})
                selected_ids.add(source_id)

        # This current meta section governs how conflicting sources are resolved.
        # Include it as standing context without consuming a relevance slot.
        if selected:
            control = self._by_source.get("KB-00.1")
            if control and "KB-00.1" not in selected_ids:
                selected.append({**control, "score": 0.0, "control": True})
        return selected
