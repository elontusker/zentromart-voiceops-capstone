"""Deterministic date arithmetic derived from the supplied refund policy."""

import csv
import re
from datetime import date, timedelta
from pathlib import Path


MONTHS = {
    name.casefold(): number
    for number, names in enumerate((
        ("January", "Jan"), ("February", "Feb"), ("March", "Mar"),
        ("April", "Apr"), ("May",), ("June", "Jun"), ("July", "Jul"),
        ("August", "Aug"), ("September", "Sep"), ("October", "Oct"),
        ("November", "Nov"), ("December", "Dec"),
    ), start=1)
    for name in names
}
MONTH_PATTERN = "|".join(sorted(MONTHS, key=len, reverse=True))


def _parse_date(question: str) -> date | None:
    match = re.search(r"\b(20\d{2})-(\d{1,2})-(\d{1,2})\b", question)
    if match:
        return date(*(int(part) for part in match.groups()))
    match = re.search(rf"\b({MONTH_PATTERN})\s+(\d{{1,2}})(?:,?\s+(20\d{{2}}))?\b", question, re.I)
    if match:
        return date(int(match.group(3) or 2026), MONTHS[match.group(1).casefold()], int(match.group(2)))
    match = re.search(rf"\b(\d{{1,2}})\s+({MONTH_PATTERN})(?:\s+(20\d{{2}}))?\b", question, re.I)
    if match:
        return date(int(match.group(3) or 2026), MONTHS[match.group(2).casefold()], int(match.group(1)))
    return None


def _policy_window(evidence: list[dict], question: str) -> tuple[int, int] | None:
    text = "\n".join(chunk["text"] for chunk in evidence if chunk["source_id"] == "REF-2")
    method = question.casefold()
    if "upi" in method:
        label = "UPI"
    elif "net banking" in method or "netbanking" in method:
        label = "Net banking"
    elif "card" in method:
        label = "Credit or debit card"
    elif "neft" in method or "bank transfer" in method:
        label = "Bank transfer (NEFT)"
    elif "wallet" in method:
        label = "ZentroMart Wallet"
    else:
        return None
    for line in text.splitlines():
        if line.strip().startswith("|") and label.casefold() in line.casefold():
            numbers = re.search(r"(\d+)\s+to\s+(\d+)\s+business days", line, re.I)
            if numbers:
                return int(numbers.group(1)), int(numbers.group(2))
            if "instant" in line.casefold():
                return 0, 0
    return None


def calendar_context(question: str, evidence: list[dict], dataset_dir: Path) -> str:
    """Return an exact policy-derived range when date, method, and REF-2 exist."""
    initiated = _parse_date(question)
    window = _policy_window(evidence, question)
    if initiated is None or window is None:
        return ""
    with (Path(dataset_dir) / "data" / "holidays.csv").open(encoding="utf-8-sig", newline="") as handle:
        holidays = {date.fromisoformat(row["date"]) for row in csv.DictReader(handle)}

    def add_business_days(start: date, count: int) -> date:
        cursor = start
        added = 0
        while added < count:
            cursor += timedelta(days=1)
            if cursor.weekday() != 6 and cursor not in holidays:
                added += 1
        return cursor

    earliest = add_business_days(initiated, window[0]) if window[0] else initiated
    latest = add_business_days(initiated, window[1]) if window[1] else initiated
    return (
        "\n\nDETERMINISTIC CALENDAR CHECK (computed from REF-2 and holidays.csv): "
        f"refund initiated {initiated:%d %B %Y}; allowed window {window[0]}–{window[1]} "
        f"business days; expected arrival range {earliest:%d %B %Y} to {latest:%d %B %Y}. "
        "If the customer asks for the due/latest date, state the latest date above."
    )
