"""Deterministic scoring helpers for the supplied practice questions."""

import re
import unicodedata


NUMBER_WORDS = {
    "zero": "0", "one": "1", "two": "2", "three": "3", "four": "4",
    "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9",
    "ten": "10", "eleven": "11", "twelve": "12", "thirteen": "13",
    "fourteen": "14", "fifteen": "15", "sixteen": "16", "seventeen": "17",
    "eighteen": "18", "nineteen": "19", "twenty": "20",
    "तीन": "3", "दो": "2", "एक": "1", "चार": "4", "पांच": "5",
    "पाँच": "5", "सात": "7", "दस": "10", "बारह": "12",
}


def normalize(text: str) -> str:
    """Lowercase and remove punctuation so simple wording differences compare."""
    value = text.casefold()
    for word, digit in NUMBER_WORDS.items():
        value = re.sub(rf"(?<!\w){re.escape(word)}(?!\w)", digit, value, flags=re.UNICODE)
    value = "".join(
        str(unicodedata.digit(char)) if unicodedata.category(char) == "Nd" else char
        for char in value
    )
    return re.sub(r"[^\w]+", " ", value, flags=re.UNICODE).strip()


def _fact_present(fact: str, reply: str, normalized_reply: str) -> bool:
    alternatives = [normalize(item) for item in fact.split(" / ")]
    if any(item and item in normalized_reply for item in alternatives):
        return True
    if any(word in fact.casefold() for word in ("refuse", "decline", "reject")):
        refusal_phrases = (
            "cannot cancel", "cannot be cancelled", "cannot be canceled",
            "can t cancel", "can t be cancelled", "can t be canceled",
            "not possible", "won t be cancelled", "won t be canceled",
            "कैंसिल नहीं किया जा सकता", "रद्द नहीं किया जा सकता",
        )
        return any(normalize(phrase) in normalized_reply for phrase in refusal_phrases)
    fact_text = fact.casefold()
    if any(term in fact_text for term in (
        "cannot confirm", "cannot verify", "not available", "human", "colleague",
        "escalat", "जानकारी नहीं", "pata nahi", "connect", "सहयोगी",
    )):
        hindi_unknown = ("उपलब्ध जानकारी से नहीं", "पुष्टि नहीं कर सकता", "पुष्टि नहीं कर सकती", "जानकारी उपलब्ध नहीं")
        hindi_handover = ("सहकर्मी", "मानवीय सहायता", "मानव एजेंट", "टीम से जुड़")
        if any(normalize(phrase) in normalized_reply for phrase in hindi_unknown) and any(
            normalize(phrase) in normalized_reply for phrase in hindi_handover
        ):
            return True
    return False


def split_list(value: str, separator: str = " ; ") -> list[str]:
    return [part.strip() for part in (value or "").split(separator) if part.strip()]


def decision_from_reply(reply: str) -> str:
    match = re.match(r"\s*DECISION:\s*(answer|clarify|escalate|refuse)\b", reply, re.I)
    return match.group(1).lower() if match else "missing"


def score_question(row: dict[str, str], reply: str) -> dict:
    decision = decision_from_reply(reply)
    accepted = {
        item.casefold()
        for item in split_list(row.get("acceptable_decisions", ""))
    }
    if not accepted:
        accepted = {row.get("expected_decision", "").casefold()}

    reply_text = normalize(reply)
    required = split_list(row.get("must_include", ""))
    missing_facts = []
    for fact in required:
        if not _fact_present(fact, reply, reply_text):
            missing_facts.append(fact)

    forbidden = split_list(row.get("must_not_include", ""))
    included_forbidden = [
        phrase for phrase in forbidden
        if normalize(phrase) and normalize(phrase) in reply_text
    ]

    return {
        "id": row.get("id", ""),
        "decision": decision,
        "decision_ok": decision in accepted,
        "missing_facts": missing_facts,
        "forbidden_claims": included_forbidden,
        "passed": decision in accepted and not missing_facts and not included_forbidden,
        "reply": reply,
    }
