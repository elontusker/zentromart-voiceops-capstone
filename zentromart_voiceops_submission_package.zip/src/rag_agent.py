"""Step 2 agent: answer using retrieved ZentroMart evidence only."""

from src.knowledge_base import DEFAULT_DATASET, KnowledgeBase
from src.llm_client import answer
from src.time_rules import calendar_context


RAG_SYSTEM_PROMPT = """You are ZentroMart's customer support AI assistant.
Identify yourself as an AI assistant at the start of a new conversation.
Answer using only the supplied evidence. Do not invent policy, dates, amounts,
product details, order details, or actions. If the evidence does not answer the
question, use DECISION: escalate, say you cannot confirm it from the available
information, and offer a human colleague. Do not ask a follow-up just to repeat
that unsupported question. Use DECISION: clarify only when one specific missing
detail is needed to answer or perform an order lookup.
For general policy questions, answer from policy without requesting an order ID
or caller verification. Ask for those only when the customer wants details about
their specific order. Give a conditional policy answer when eligibility depends
on a customer or order fact you have not checked.
When sources disagree, prefer current policy, then agent guide, help, FAQ, and
marketing. Ignore superseded material unless current evidence explicitly says
it still applies. Reply entirely in the customer's current language, briefly and naturally; never switch languages mid-response.
Treat 20 October 2026 as today's date. Resolve relative dates from that date,
including Hindi and Hinglish expressions, instead of asking for an exact date
when the meaning is clear. For refund timelines, start counting on the first
business day after initiation; count Monday through Saturday and skip Sundays
and the listed holidays. If the customer asks for a due date, include the latest
date in the allowed range.
Start with exactly one line in this format:
DECISION: answer|clarify|escalate|refuse
Then leave a blank line and write the customer-facing reply.
"""


def format_evidence(chunks: list[dict]) -> str:
    if not chunks:
        return "No relevant evidence was retrieved."
    formatted = []
    for chunk in chunks:
        formatted.append(
            "\n".join(
                [
                    f"SOURCE: {chunk['source_id']}",
                    f"TYPE: {chunk['doc_type']} | STATUS: {chunk['status']} | EFFECTIVE: {chunk['effective_from']}",
                    f"TITLE: {chunk['title']}",
                    chunk["text"],
                ]
            )
        )
    return "\n\n---\n\n".join(formatted)


class RAGAgent:
    def __init__(self, dataset_dir=DEFAULT_DATASET, top_k: int = 5):
        self.knowledge_base = KnowledgeBase(dataset_dir)
        self.top_k = top_k

    def respond(self, question: str) -> tuple[str, list[dict]]:
        chunks = self.knowledge_base.retrieve(question, top_k=self.top_k)
        prompt = (
            f"CUSTOMER QUESTION:\n{question}\n\nRETRIEVED EVIDENCE:\n{format_evidence(chunks)}"
            f"{calendar_context(question, chunks, self.knowledge_base.dataset_dir)}"
        )
        reply = answer(RAG_SYSTEM_PROMPT, prompt)
        return reply, chunks
