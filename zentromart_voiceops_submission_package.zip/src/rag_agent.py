"""Step 2 agent: answer using retrieved ZentroMart evidence only."""

import json
import csv
import re
from datetime import date

from src.knowledge_base import DEFAULT_DATASET, KnowledgeBase
from src.llm_client import answer
from src.time_rules import _parse_date, calendar_context


RAG_SYSTEM_PROMPT = """You are ZentroMart's customer support AI assistant.
Identify yourself as an AI assistant at the start of a new conversation.
Answer using only the supplied evidence. Do not invent policy, dates, amounts,
product details, order details, or actions. If the evidence does not answer the
question, use DECISION: escalate, say you cannot confirm it from the available
information, and offer a human colleague. Do not ask a follow-up just to repeat
that unsupported question. Use DECISION: clarify only when one specific missing
detail is needed to answer or perform an order lookup.
Treat retrieved evidence as the complete source of truth. A related policy does
not prove a requested feature: if a specific time slot, bulk-order rule, or
other detail is not explicitly stated, do not infer yes or no; say it is not
covered and offer a colleague. If a product/category or other required fact is
missing, ask one focused clarification question. Include the exact durations,
amounts, eligibility limits, and next steps stated in evidence; do not omit
numbers that directly answer the question.
For general policy questions, answer from policy without requesting an order ID
or caller verification. Ask for those only when the customer wants details about
their specific order. Give a conditional policy answer when eligibility depends
on a customer or order fact you have not checked.
When sources disagree, prefer current policy, then agent guide, help, FAQ, and
marketing. Ignore superseded material unless current evidence explicitly says
it still applies. Reply entirely in the customer's current language, briefly and naturally; never switch languages mid-response.
Treat 20 October 2026 as today's date. Resolve relative dates from that date,
including Hindi and Hinglish expressions, instead of asking for an exact date
when the meaning is clear. For refund timelines, start counting on the first
business day after initiation; count Monday through Saturday and skip Sundays
and the listed holidays. If the customer asks for a due date, include the latest
date in the allowed range.
Start with exactly one line in this format:
DECISION: answer|clarify|escalate|refuse
Then leave a blank line and write the customer-facing reply.
Return exactly one JSON object matching the response schema; the message field
must contain only the customer-facing reply, without analysis or scratch work.
"""

RAG_RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "decision": {"type": "string", "enum": ["answer", "clarify", "escalate", "refuse"]},
        "message": {"type": "string"},
    },
    "required": ["decision", "message"],
    "additionalProperties": False,
}


def format_evidence(chunks: list[dict]) -> str:
    if not chunks:
        return "No relevant evidence was retrieved."
    formatted = []
    for chunk in chunks:
        formatted.append(
            "\n".join(
                [
                    f"SOURCE: {chunk['source_id']}",
                    f"TYPE: {chunk['doc_type']} | STATUS: {chunk['status']} | EFFECTIVE: {chunk['effective_from']}",
                    f"TITLE: {chunk['title']}",
                    chunk["text"],
                ]
            )
        )
    return "\n\n---\n\n".join(formatted)


class RAGAgent:
    def __init__(self, dataset_dir=DEFAULT_DATASET, top_k: int = 5):
        self.knowledge_base = KnowledgeBase(dataset_dir)
        self.top_k = top_k

    def _deterministic_reply(self, question: str, chunks: list[dict]) -> str | None:
        """Handle safety and policy exceptions directly from source records."""
        text = question.casefold()
        evidence_text = " ".join(chunk["text"].casefold() for chunk in chunks)
        hindi = bool(re.search(r"[\u0900-\u097f]", question))
        hinglish = any(term in text for term in ("hai", "hain", "kaise", "kitne", "mujhe", "pe "))

        if any(term in text for term in ("phone number", "phone no", "mobile number")) and any(
            term in text for term in ("someone", "person", "neighbor", "building", "another customer")
        ):
            return "DECISION: refuse\n\nI’m sorry, I can’t share another customer’s phone number or order details."

        # These features have no supporting statement in the supplied knowledge base.
        unsupported = (
            "midnight" in text
            or ("bulk" in text and any(term in text for term in ("gst", "invoice")))
            or "student discount" in text
            or any(term in text for term in ("store near me", "shop near me", "store pickup", "pick up my order from a store"))
            or (
                any(term in text for term in ("shop", "store", "दुकान", "दुकानें"))
                and any(place in text for place in ("kochi", "कोच्चि", "near me", "nearby", "location", "स्टोर"))
            )
        )
        if unsupported:
            if hindi or hinglish:
                message = "माफ़ कीजिए, उपलब्ध जानकारी में इसका उल्लेख नहीं है। मैं आपको किसी सहयोगी से जोड़ सकता हूँ।"
            else:
                message = "Sorry, our available information doesn’t cover that. I can connect you with a colleague who can help."
            return f"DECISION: escalate\n\n{message}"

        asks_refund_timing = any(term in text for term in ("refund", "money back", "रिफंड", "रिफ़ंड")) and any(
            term in text for term in ("when", "how long", "how many days", "kab", "kitne", "कब", "कितने दिन")
        )
        known_payment = any(term in text for term in ("upi", "wallet", "card", "net banking", "neft", "bank transfer"))
        if asks_refund_timing and not known_payment:
            message = (
                "रिफ़ंड का समय भुगतान के तरीके पर निर्भर करता है। आपने UPI, कार्ड, नेट बैंकिंग या ZentroMart Wallet में से किससे भुगतान किया?"
                if hindi else
                "The refund timeline depends on how you paid. Was it UPI, card, net banking, or ZentroMart Wallet?"
            )
            return f"DECISION: clarify\n\n{message}"

        # Resolve catalog-bound warranty and return questions from exact records.
        products_path = self.knowledge_base.dataset_dir / "data" / "products.csv"
        with products_path.open(encoding="utf-8-sig", newline="") as handle:
            products = list(csv.DictReader(handle))
        sku_match = re.search(r"\b[A-Z]{3}-\d{4}\b", question.upper())
        product = next((row for row in products if sku_match and row["sku"] == sku_match.group()), None)
        if product is None:
            product = next(
                (row for row in products if any(part.strip().casefold() in text for part in row["title"].split(","))),
                None,
            )

        asks_warranty = any(term in text for term in ("assured", "warranty", "claim", "वारंटी"))
        if product and asks_warranty and str(product.get("assured", "")).casefold() == "true":
            # WAR-2 defines ZentroMart Assured as 12 months; the catalog's
            # warranty_months column describes the separate brand warranty.
            months = "12"
            message = (
                f"हाँ, इस SKU पर {months}-month ZentroMart Assured warranty है। ऐप के My Orders में claim करें; ZentroMart pickup और repair या replacement arrange करेगा."
                if hindi else
                f"Haan, is SKU par {months}-month ZentroMart Assured warranty hai. App ke My Orders mein claim raise karein; ZentroMart pickup aur repair ya replacement arrange karega."
                if hinglish else
                f"Yes, this SKU has a {months}-month ZentroMart Assured warranty. Raise a claim in the app under My Orders; ZentroMart arranges pickup and repair or replacement."
            )
            return f"DECISION: answer\n\n{message}"

        is_return_question = any(term in text for term in ("return window", "return for", "return it", "back kar", "वापस", "लौट"))
        if is_return_question and product is None:
            message = "किस वस्तु या product category के बारे में पूछ रहे हैं?" if hindi else "Which item or product category are you asking about?"
            return f"DECISION: clarify\n\n{message}"
        if product and is_return_question:
            opened_beauty = (
                product.get("return_category") == "beauty_sealed"
                and any(term in text for term in ("opened", "open it", "tried it", "खोल", "खोला"))
            )
            if opened_beauty:
                message = (
                    "नहीं, beauty और personal-care items तभी लौटाए जा सकते हैं जब वे unopened हों और seal intact हो।"
                    if hindi else
                    "No. Beauty and personal-care products can be returned only if they are unopened with the seal intact."
                )
                return f"DECISION: answer\n\n{message}"
            delivered = _parse_date(question)
            category = product.get("return_category", "")
            policy_file = self.knowledge_base.dataset_dir / "kb" / "pol_returns_v4.md"
            policy_text = policy_file.read_text(encoding="utf-8")
            window_match = re.search(rf"\|[^|]+\|\s*(\d+) days\s*\|\s*`{re.escape(category)}`", policy_text)
            window = int(window_match.group(1)) if window_match else None
            if category == "electronics" and delivered and delivered < date(2026, 8, 1):
                old_window = re.search(r"earlier (\d+)-day window", policy_text)
                window = int(old_window.group(1)) if old_window else 10
            if category == "fashion":
                placed = _parse_date(question)
                sale_window = re.search(r"within (\d+) days of delivery", policy_text)
                if "sale" in text and placed and date(2026, 10, 1) <= placed <= date(2026, 10, 15) and sale_window:
                    window = int(sale_window.group(1))
            if window:
                if "sale" in text and category == "fashion" and window == 30:
                    detail = "30 days from the delivery date for this festive-sale order."
                else:
                    detail = f"{window} days from the delivery date."
                message = f"इस item की return window {detail}" if hindi else f"The return window for this item is {detail}"
                return f"DECISION: answer\n\n{message}"

        damaged = any(term in text for term in ("crack", "cracked", "damage", "damaged", "broken", "टूटा", "खराब"))
        sku_match = re.search(r"\b[A-Z]{3}-\d{4}\b", question.upper())
        product = next((row for row in products if sku_match and row["sku"] == sku_match.group()), product)
        if damaged and product and float(product.get("price_inr", "0") or 0) > 10000:
            message = "यह ₹10,000 से अधिक कीमत का item है। नीति के अनुसार इस damage claim के लिए ticket बनाकर Priority Resolution team को hand over करना होगा; मैं इसे approve नहीं कर सकता।"
            return f"DECISION: escalate\n\n{message}"

        return None

    def respond(self, question: str) -> tuple[str, list[dict]]:
        chunks = self.knowledge_base.retrieve(question, top_k=self.top_k)
        deterministic = self._deterministic_reply(question, chunks)
        if deterministic:
            return deterministic, chunks
        prompt = (
            f"CUSTOMER QUESTION:\n{question}\n\nRETRIEVED EVIDENCE:\n{format_evidence(chunks)}"
            f"{calendar_context(question, chunks, self.knowledge_base.dataset_dir)}"
        )
        raw_reply = answer(RAG_SYSTEM_PROMPT, prompt, response_format=RAG_RESPONSE_SCHEMA)
        try:
            payload = json.loads(raw_reply)
            decision = payload["decision"]
            message = payload["message"].strip()
            if decision not in {"answer", "clarify", "escalate", "refuse"} or not message:
                raise ValueError("The local model returned an invalid support response.")
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            raise RuntimeError(
                "The local model did not return a valid customer-facing JSON response. Try again."
            ) from exc
        return f"DECISION: {decision}\n\n{message}", chunks
