"""Minimal Gemini REST client using only Python's standard library."""

import json
import os
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


def _load_local_env() -> None:
    """Read simple KEY=value settings from the project .env file."""
    env_path = Path(__file__).resolve().parent.parent / ".env"
    if not env_path.exists():
        return

    for line in env_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        key = key.strip()
        value = value.strip().strip("\"'")
        if key and key not in os.environ:
            os.environ[key] = value


def answer(system_prompt: str, user_message: str) -> str:
    """Send one text turn to Gemini and return its response."""
    _load_local_env()
    api_key = os.getenv("LLM_API_KEY", "").strip()
    model = os.getenv("LLM_MODEL", "").strip()
    base_url = os.getenv(
        "LLM_BASE_URL", "https://generativelanguage.googleapis.com/v1beta"
    ).strip().rstrip("/")

    if not api_key or api_key == "replace_me":
        raise RuntimeError("Add your Gemini key to the LLM_API_KEY line in .env.")
    if not model:
        raise RuntimeError("Set LLM_MODEL in .env.")

    url = f"{base_url}/models/{model}:generateContent?{urlencode({'key': api_key})}"
    payload = {
        "systemInstruction": {"parts": [{"text": system_prompt}]},
        "contents": [{"role": "user", "parts": [{"text": user_message}]}],
        "generationConfig": {"temperature": 0.2},
    }
    request = Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urlopen(request, timeout=60) as response:
            result = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        # Do not include the request URL here; it contains the private API key.
        raise RuntimeError(
            f"Gemini API returned HTTP {exc.code}. Check the key, model, and free-tier quota."
        ) from None
    except URLError:
        raise RuntimeError("Could not reach the Gemini API. Check your connection.") from None

    parts = result.get("candidates", [{}])[0].get("content", {}).get("parts", [])
    text = "".join(part.get("text", "") for part in parts).strip()
    if not text:
        raise RuntimeError("Gemini returned no text for this question.")
    return text
