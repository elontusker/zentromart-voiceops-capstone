"""Small local Ollama client used by every text and voice agent step."""

import json
import os
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


def _load_local_env() -> None:
    """Read simple KEY=value settings from the project .env file."""
    env_path = Path(__file__).resolve().parent.parent / ".env"
    if not env_path.exists():
        return

    for line in env_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        key = key.strip()
        value = value.strip().strip("\"'")
        if key and key not in os.environ:
            os.environ[key] = value


def answer(system_prompt: str, user_message: str, response_format: dict | None = None) -> str:
    """Send one prompt to the local Ollama server and return its text response."""
    _load_local_env()
    model = os.getenv("LLM_MODEL", "qwen3:4b").strip()
    base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").strip().rstrip("/")
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ],
        "stream": False,
        # Qwen3 supports the API's boolean switch; disabling chain-of-thought
        # keeps the customer-support turn short and returns only the answer.
        "think": False,
        "options": {"temperature": 0.2},
    }
    if response_format is not None:
        payload["format"] = response_format
    request = Request(
        f"{base_url}/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urlopen(request, timeout=180) as response:
            result = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        raise RuntimeError(
            f"Ollama returned HTTP {exc.code}. Check that Ollama is running and model '{model}' is installed."
        ) from None
    except URLError:
        raise RuntimeError(
            "Ollama is not running. Install Ollama, open it, then download the project model before starting the agent."
        ) from None

    text = result.get("message", {}).get("content", "").strip()
    if not text:
        raise RuntimeError("The local model returned no text. Try again or check the Ollama model.")
    return text
