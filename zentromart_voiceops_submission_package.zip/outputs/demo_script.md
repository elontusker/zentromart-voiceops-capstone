# Two-minute ZentroMart VoiceOps demo video

## Before recording

- Keep the successful PowerShell run visible and Snipping Tool in Record mode.
- Use the three folders in `work/results/voice_batch/` and the input recordings in `work/demo_audio/`.
- In Snipping Tool, turn on microphone and system audio if those controls are available. Play the WAVs through the computer speakers so the recording includes them.
- Keep `.env` and all API keys off screen. Use only the supplied synthetic dataset and ticket data.
- Keep this script nearby to read. The timestamps are a guide.

| Time | Show / do | Say |
|---|---|---|
| 0:00–0:15 | Show the successful PowerShell run output. | “This is ZentroMart VoiceOps, a customer-support capstone. Gnani converts speech to text and speaks the reply. Local Qwen generates the answer using company policy evidence.” |
| 0:15–0:45 | Play `work/demo_audio/01_opened_product.wav`, then play `work/results/voice_batch/01_opened_product/assistant_reply.wav`. Show `transcript.txt` and `assistant_reply.txt`. | “The customer asks, ‘Can I return an opened product?’ The assistant asks which product, rather than guessing, because the return rule depends on the product.” |
| 0:45–1:10 | Play `work/demo_audio/02_return_window.wav`. Show `work/results/voice_batch/02_return_window/assistant_reply.txt` and play its `assistant_reply.wav` so the follow-up answer is heard. | “The customer follows up, ‘And what is the return window for it?’ The assistant keeps the conversation context and explains the return windows by product category.” |
| 1:10–1:35 | Play `work/demo_audio/03_human_handoff.wav`. Show `work/results/voice_batch/03_human_handoff/assistant_reply.txt` and play its `assistant_reply.wav`. | “When the customer asks for a human, the support tool creates a local ticket and the assistant speaks the confirmation.” |
| 1:35–1:55 | Show the three result folders or the PowerShell run output. | “All three recordings were transcribed and received a spoken answer. The project also retrieves policy sources. Its reported evaluation scores use the supplied synthetic practice data; they do not guarantee performance on unseen questions.” |
| 1:55–2:00 | Show the project name. | “That is the ZentroMart VoiceOps demonstration.” |

## Saving the video

Save the finished recording as `demo.mp4` in the project's `outputs` folder.
