# 2-minute capstone demo script (record on your computer)

**0:00-0:15 | Problem**  
"This is ZentroMart VoiceOps, a customer-support capstone. It uses local Qwen for replies, local embeddings for evidence search, and Gnani for speech. It must answer from approved policy, verify identity before revealing order details, and hand qualifying cases to a human."

**0:15-0:35 | RAG**  
Ask: "Can I return an opened product?" Then ask: "What is the return window for this item?" Show the answer and its source IDs. Explain that the local vector search blends meaning-based matching with exact policy terms.

**0:35-1:10 | Verified order flow**  
Start the multi-turn agent and ask about a specific order. Show that it asks for the order ID, then a verification value, before using order facts. Use only synthetic practice IDs and values from the supplied dataset. Show a policy escalation case creating a local mock ticket.

**1:10-1:40 | Voice**  
Play a WAV input through the official Gnani SDK, then show its transcript, the local Qwen answer, retrieved source IDs, and synthesized reply. If time allows, show two ordered WAV turns in batch `--conversation` mode to demonstrate carried verification state.

**1:40-2:00 | Evaluation and close**  
"The hybrid retriever found every expected source for 47 of 47 answerable practice questions, and the RAG flow passed 52 of 52 supplied questions. The local tool agent passed 96 of 96 supplied conversation turns. Gnani speech and local Qwen replies passed a synthetic single-turn and batch check. These are synthetic practice results, not a guarantee on unseen questions. A real microphone recording, multi-turn spoken order verification, and this demo video are the remaining submission checks."
