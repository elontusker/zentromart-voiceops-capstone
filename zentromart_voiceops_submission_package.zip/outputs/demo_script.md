# 2-minute demo script (to record after Gnani access)

**0:00-0:15 | Problem**  
"This is ZentroMart VoiceOps, a customer-support capstone. The assistant must answer from approved policy, protect order details with verification, and hand qualifying cases to a human."

**0:15-0:35 | RAG**  
Ask: "Can I return an opened product?" Then ask a follow-up: "What is the return window for this item?" Show the answers and their source IDs. Explain that the retriever searches policy before answering.

**0:35-1:10 | Verified order flow**  
Start the multi-turn agent and ask about a specific order. Show that it asks for the order ID, then a verification value, before using order facts. Use only synthetic practice IDs and values from the supplied dataset. Show a policy escalation case creating a local mock ticket.

**1:10-1:40 | Voice**  
Play the synthetic WAV sample that has already passed through the official Gnani SDK. For a spoken follow-up, put two self-recorded WAV turns in a folder in order and run batch mode with `--conversation`; show the transcript, reply audio, retrieved source IDs, and a verified order handover.

**1:40-2:00 | Evaluation and close**  
"RAG found all expected evidence for 47 of 47 answerable practice questions and passed 52 of 52 reviewed questions. The initial multi-turn run passed 82 of 96 turns; targeted fixes were verified, but Gemini's free-tier rate limit blocked a complete post-fix rerun. The synthetic voice flow and one-file batch test passed using the official SDK. A real microphone recording, a multi-turn spoken order flow, and this demo video are the remaining submission checks."
