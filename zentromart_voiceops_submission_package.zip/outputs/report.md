# ZentroMart VoiceOps Capstone - Final Project Report

**Prepared:** 22 October 2026  
**Dataset reference date:** 20 October 2026  
**Project:** Synthetic customer support assistant with text, retrieval, verified tools, and voice adapters

## Executive summary

This capstone builds a customer-support assistant in four stages. It begins with a prompt-only baseline using local Qwen3 4B, adds a local embedding vector index over the supplied synthetic company knowledge base, introduces multi-turn order verification and guarded support-ticket tools, then adds Gnani speech-to-text and text-to-speech adapters. The data and policy rules are synthetic and are used only for this educational project.

The retrieval stage uses local `nomic-embed-text` vectors fused with BM25 ranking and policy routes; it found all expected evidence for 47/47 answerable questions at top five. The final RAG flow passed 52/52 questions with 100% decision accuracy and 100% gold-source recall. The baseline passed 8/52 literal required-fact checks. The final multi-turn result is 96/96: the full suite passed 92/96, then four corrected scenarios (17 turns) passed on focused replay. The synthetic single-turn voice flow and one-file batch test passed end to end with Gnani STT/TTS and local Qwen. A user-recorded microphone sample, multi-file voice order-verification dialogue, and the required short demo video remain to be completed.

## Problem and goals

Customers ask policy questions and questions about particular orders. The assistant must answer from company sources, ask for the order ID and verify a second identifier before disclosing order-specific information, avoid exposing personal data, and create a human handover only for qualifying escalations. The final stage must accept audio, transcribe it through Gnani, run the support flow, synthesize an audio reply through Gnani, and save outputs and evidence references for batch recordings.

## Implementation

### Stage 1 - Prompt-only baseline

The local Qwen3 4B model answers without document retrieval. This stage establishes a simple baseline and shows the limits of relying on the model's general knowledge. Ollama serves the model locally; no hosted LLM API key is required.

### Stage 2 - Retrieval-augmented generation

A local `nomic-embed-text` model embeds policy sections and approved catalog/pincode records. A persistent vector cache stores the embeddings outside the submission package. Retrieval fuses cosine similarity with BM25 lexical ranking, exact SKU matching, English/Hindi/Hinglish search variants, and policy routes for safety-critical topics. Retrieved evidence is attached to model context and source IDs are exposed. Business-day refund timelines use the policy's duration and supplied holiday calendar; return deadlines use calendar-day arithmetic and verified order dates.

### Stage 3 - Multi-turn tools

The tool agent stores conversation state in memory and supports order lookup and ticket creation via the dataset's local mock tools. A specific order lookup requires an order ID and either the registered phone's last four digits or delivery pincode. Verification proof and contact fields are filtered from model context and ticket summaries. The code limits verification attempts and gates ticket creation on explicit human request or policy escalation conditions. The dataset's tools are mock educational tools, not production services.

### Stage 4 - Voice

Gnani STT and TTS are implemented through the official gnani-vachana Python SDK. The batch runner accepts mono 16 kHz, 16-bit PCM WAV files and saves a transcript, assistant text, synthesized WAV, tool-call record, and retrieved source IDs for each recording. The synthetic single-turn and one-file batch paths both passed end to end with the official SDK. The batch runner can preserve one support session across ordered audio turns with the `--conversation` option; multi-file order verification has not yet been exercised. A user-recorded microphone sample and the required short demo video remain outstanding.

## Evaluation

| Stage | Evaluation | Result | Interpretation |
|---|---|---:|---|
| Prompt-only baseline | 52 practice questions | 8/52 passed fact checks | Literal matching; no knowledge base; 49/52 escalated conservatively |
| Retrieval | 47 answerable questions, top-k 5 | 47/47 all gold evidence found | Local embedding + BM25 hybrid index; 100% evidence coverage on the answerable subset |
| RAG | 52 practice questions | 52/52 passed | 100% decision accuracy and gold-source recall; four edge-case fixes confirmed by focused replay |
| Multi-turn tools | 96 supplied turns | 96/96 passed | Full run 92/96 plus focused replay 17/17 across four corrected scenarios |
| Gnani voice | One synthetic input; single + batch | Passed | Gnani official SDK STT/TTS with local Qwen reply; real recording and demo video remain pending |

The practice set is synthetic and small; results do not guarantee performance on unseen evaluation prompts. RAG and multi-turn results include focused replays after the initial full runs and are saved with their methodology in `work/results/`. The 96/96 tool-agent score covers only the supplied synthetic conversation turns.

## How to run

Use Python 3.10 or newer, install Ollama and the models `qwen3:4b` and `nomic-embed-text`, and install packages from `requirements.txt`. Extract the supplied dataset to `work/dataset/Capstone_Project_Dataset_FTTT_2026`. Copy `.env.example` to `.env` and set `GNANI_API_KEY` only for voice features. Never publish `.env`.

Commands for the baseline, retrieval, RAG, and tool-agent stages are in the project README. For voice batch processing:

`python run_voice_batch.py path/to/audio_folder --language en-IN --voice-language auto`

Voice input must be mono 16 kHz 16-bit PCM WAV. The provided dataset contains no audio recordings.

## Submission and limitations

The source package is prepared without the dataset, vector cache, virtual environment, generated ticket file, or secrets. A public GitHub repository is available, but a deployed demo and required demo video (maximum two minutes) remain outstanding. Record a user voice sample, demonstrate multi-turn voice order verification, and produce the short demo showing a document-grounded question with follow-up plus a handover or safe refusal.

## Sources

- Supplied *VoiceOps 2026 Capstone Brief* and synthetic FTTT dataset, including its README, policies, practice questions, tables, and mock tools.
- Gnani official SDK, `gnani-vachana`: `https://github.com/Gnani-AI-Mintlify/Gnani-Vachana`; Gnani API documentation at `https://docs.gnani.ai/api/`.
- Ollama local model runtime; Qwen3 4B for generation and `nomic-embed-text` for embeddings.
