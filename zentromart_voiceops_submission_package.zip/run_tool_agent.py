"""Run the multi-turn tool-using agent in a local terminal session."""

from src.tool_agent import ToolAgent


def main() -> None:
    agent = ToolAgent()
    print("ZentroMart support is ready. Type 'quit' to end the conversation.")
    while True:
        try:
            message = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nConversation ended.")
            return
        if message.casefold() in {"quit", "exit"}:
            print("Conversation ended.")
            return
        if not message:
            continue
        try:
            response, tools = agent.respond(message)
        except (RuntimeError, ValueError) as exc:
            print(f"Assistant: {exc}")
            continue
        print(f"Assistant: {response}")
        if tools:
            print(f"[Internal tool calls this turn: {', '.join(tools)}]")


if __name__ == "__main__":
    main()
