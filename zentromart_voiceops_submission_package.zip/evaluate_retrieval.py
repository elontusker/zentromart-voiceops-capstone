"""Measure whether the retriever finds the practice set's gold evidence."""

import argparse
import csv
import json
from pathlib import Path

from src.knowledge_base import DEFAULT_DATASET, KnowledgeBase


PROJECT_ROOT = Path(__file__).resolve().parent
DEFAULT_OUTPUT = PROJECT_ROOT / "work" / "results" / "retrieval_eval.json"


def main() -> None:
    parser = argparse.ArgumentParser(description="Score retrieval on practice questions.")
    parser.add_argument("--dataset-dir", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--top-k", type=int, default=5)
    args = parser.parse_args()

    knowledge_base = KnowledgeBase(args.dataset_dir)
    questions_path = args.dataset_dir / "practice" / "questions.csv"
    with questions_path.open(encoding="utf-8-sig", newline="") as handle:
        questions = list(csv.DictReader(handle))
    # Embed the whole evaluation set in batches instead of making 52 separate
    # local model calls; normal interactive use still embeds one query at a time.
    query_vectors = knowledge_base._embed([row["question"] for row in questions])

    results = []
    for row, query_vector in zip(questions, query_vectors):
        retrieved = knowledge_base.retrieve(
            row["question"], top_k=args.top_k, query_vector=query_vector
        )
        expected = [item.strip() for item in row["gold_evidence"].split(" ; ") if item.strip()]
        returned = [chunk["source_id"] for chunk in retrieved]
        matched = [item for item in expected if item in returned]
        results.append(
            {
                "id": row["id"],
                "language": row["language"],
                "expected_evidence": expected,
                "retrieved_evidence": returned,
                "matched_evidence": matched,
                "recall": len(matched) / len(expected) if expected else None,
            }
        )

    answerable = [item for item in results if item["expected_evidence"]]
    all_evidence_found = sum(item["recall"] == 1 for item in answerable)
    evidence_items = sum(len(item["matched_evidence"]) for item in answerable)
    total_expected = sum(len(item["expected_evidence"]) for item in answerable)
    summary = {
        "question_count": len(results),
        "answerable_question_count": len(answerable),
        "top_k": args.top_k,
        "questions_with_all_gold_evidence": all_evidence_found,
        "all_evidence_recall_rate": round(all_evidence_found / len(answerable), 4) if answerable else 0,
        "chunk_recall": round(evidence_items / total_expected, 4) if total_expected else 0,
        "results": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        f"Retrieved every gold source for {all_evidence_found}/{len(answerable)} answerable questions "
        f"({summary['all_evidence_recall_rate']:.1%}); chunk recall {summary['chunk_recall']:.1%}."
    )
    print(f"Saved details to {args.output}")


if __name__ == "__main__":
    main()
