"""Evaluate Step 3 on the supplied multi-turn practice conversations."""

import csv
import argparse
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path

from src.knowledge_base import DEFAULT_DATASET, KnowledgeBase
from src.tool_agent import ToolAgent


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "work" / "results" / "tool_agent_eval.json"


def norm(text: str) -> str:
    value = unicodedata.normalize("NFC", text).casefold()
    value = re.sub(r"\b(\d{1,2})(?:st|nd|rd|th)\s+(?:of\s+)?", r"\1 ", value)
    return re.sub(r"[^\w]+", " ", value).strip()


def fact_groups(value: str) -> list[list[str]]:
    return [[part.strip() for part in group.split(" / ") if part.strip()]
            for group in (value or "").split(" ; ") if group.strip()]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--conversation-id", action="append", help="Evaluate only this scenario (repeatable).")
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    dataset = Path(DEFAULT_DATASET)
    with (dataset / "practice" / "conversations.csv").open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if args.conversation_id:
        requested = set(args.conversation_id)
        rows = [row for row in rows if row["conversation_id"] in requested]
        missing = requested - {row["conversation_id"] for row in rows}
        if missing:
            parser.error(f"Unknown conversation IDs: {', '.join(sorted(missing))}")
    groups: dict[str, list[dict[str, str]]] = {}
    for row in rows:
        groups.setdefault(row["conversation_id"], []).append(row)

    # Precompute the practice utterance embeddings in batches. The agent still
    # uses one vector query per user turn in real conversations.
    messages = list(dict.fromkeys(row["customer_message"] for row in rows))
    query_vectors = KnowledgeBase(dataset)._embed(messages)
    precomputed = dict(zip(messages, query_vectors))

    results = []
    for conversation_id, turns in groups.items():
        agent = ToolAgent(dataset)
        agent.kb._query_vectors = precomputed
        for index, row in enumerate(turns):
            try:
                reply, tool_calls = agent.respond(row["customer_message"])
            except Exception as exc:  # Save progress, including provider/quota errors.
                result = {"conversation_id": conversation_id, "turn": row["turn"], "error": str(exc)}
                results.append(result)
                args.output.parent.mkdir(parents=True, exist_ok=True)
                args.output.write_text(json.dumps({"completed_turns": len(results), "total_turns": len(rows), "results": results}, ensure_ascii=False, indent=2), encoding="utf-8")
                print(f"Stopped at {conversation_id} turn {row['turn']}: {exc}", flush=True)
                return

            text = norm(reply)
            needed = fact_groups(row["must_include"])
            missing = [" / ".join(group) for group in needed if not any(norm(fact) in text for fact in group)]
            forbidden_groups = fact_groups(row["must_not_include"])
            forbidden = [" / ".join(group) for group in forbidden_groups if any(norm(fact) in text for fact in group)]
            expected_tools = Counter(re.findall(r"lookup_order|create_ticket", row["expected_tool_calls"]))
            actual_tools = Counter(tool_calls)
            expected_decision = row["expected_decision"]
            actual_decision = agent.last_decision
            result = {
                "conversation_id": conversation_id,
                "scenario": row["scenario"],
                "turn": int(row["turn"]),
                "expected_decision": expected_decision,
                "actual_decision": actual_decision,
                "decision_ok": expected_decision == actual_decision,
                "expected_tools": dict(expected_tools),
                "actual_tools": dict(actual_tools),
                "tools_ok": expected_tools == actual_tools,
                "missing_required_facts": missing,
                "forbidden_claims": forbidden,
                "passed": expected_decision == actual_decision and expected_tools == actual_tools and not missing and not forbidden,
                "reply": reply,
            }
            results.append(result)
            args.output.parent.mkdir(parents=True, exist_ok=True)
            passed = sum(bool(item.get("passed")) for item in results)
            args.output.write_text(json.dumps({"stage": "step_3_tool_agent", "completed_turns": len(results), "total_turns": len(rows), "passed_count": passed, "results": results}, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"[{len(results)}/{len(rows)}] {conversation_id} turn {row['turn']}: {'PASS' if result['passed'] else 'REVIEW'}", flush=True)
    print(f"Step 3: {sum(bool(item.get('passed')) for item in results)}/{len(results)} turns passed. Results: {args.output}")


if __name__ == "__main__":
    main()
