"""Ask the Step 2 document-grounded ZentroMart agent one question."""

import argparse
import sys

from src.rag_agent import RAGAgent


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description="Ask the ZentroMart RAG agent.")
    parser.add_argument("question", help="The customer's question")
    parser.add_argument("--dataset-dir", help="Path to the extracted capstone dataset")
    parser.add_argument("--top-k", type=int, default=5)
    args = parser.parse_args()

    agent = RAGAgent(dataset_dir=args.dataset_dir, top_k=args.top_k) if args.dataset_dir else RAGAgent(top_k=args.top_k)
    reply, sources = agent.respond(args.question)
    print(reply)
    print("\nRetrieved sources:")
    for source in sources:
        print(f"- {source['source_id']} ({source['title']})")


if __name__ == "__main__":
    main()
