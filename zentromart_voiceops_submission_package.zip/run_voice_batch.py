"""Process every short WAV in a folder and save text, sources, and reply audio."""

import argparse
import json
from pathlib import Path

from src.gnani_voice import synthesize_wav, transcribe_wav
from src.tool_agent import ToolAgent


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("audio_folder", type=Path, help="Folder containing mono 16 kHz, 16-bit PCM WAV files")
    parser.add_argument("--language", default="en-IN", help="Gnani STT language code (en-IN or hi-IN)")
    parser.add_argument("--voice-language", default="auto", help="Gnani TTS language code or auto")
    parser.add_argument("--output-dir", type=Path, default=Path("work/results/voice_batch"))
    parser.add_argument(
        "--conversation",
        action="store_true",
        help="Keep one support-agent session across alphabetically ordered WAV turns",
    )
    args = parser.parse_args()
    files = sorted(args.audio_folder.glob("*.wav"))
    if not files:
        raise SystemExit(f"No .wav files found in {args.audio_folder}")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    conversation_agent = ToolAgent() if args.conversation else None

    for audio_path in files:
        folder = args.output_dir / audio_path.stem
        folder.mkdir(parents=True, exist_ok=True)
        transcript = transcribe_wav(audio_path, args.language)
        # By default, each file represents its own request. In conversation mode,
        # one agent carries verification and policy context across sorted audio turns.
        agent = conversation_agent or ToolAgent()
        reply, tool_calls = agent.respond(transcript)
        synthesize_wav(reply, folder / "assistant_reply.wav", args.voice_language)
        (folder / "transcript.txt").write_text(transcript, encoding="utf-8")
        (folder / "assistant_reply.txt").write_text(reply, encoding="utf-8")
        record = {
            "input_audio": audio_path.name,
            "transcript": transcript,
            "assistant_reply": reply,
            "tool_calls": tool_calls,
            "retrieved_sources": [chunk["source_id"] for chunk in agent.kb.retrieve(transcript, top_k=5)],
        }
        (folder / "turn.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"{audio_path.name} -> {folder}")


if __name__ == "__main__":
    main()
